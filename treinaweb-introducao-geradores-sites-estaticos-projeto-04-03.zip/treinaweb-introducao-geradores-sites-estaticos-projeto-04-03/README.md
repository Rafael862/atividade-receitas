
# TreinaWeb: curso ["Introdução a Geradores de Sites Estáticos"](https://www.treinaweb.com.br/curso/)



#### Lista de branches
|  | Branch | Descrição |
| ------ | ------ |  ------ | 
[Download](https://github.com/treinaweb/treinaweb-introducao-geradores-sites-estaticos/archive/projeto-03-01.zip)    |  projeto-03-01     | Projeto: Iniciando um Projeto com o Next.js |
[Download](https://github.com/treinaweb/treinaweb-introducao-geradores-sites-estaticos/archive/projeto-04-01.zip)    |  projeto-04-01     | Projeto: Criando Elementos com Significado |
[Download](https://github.com/treinaweb/treinaweb-introducao-geradores-sites-estaticos/archive/projeto-04-02.zip)    |  projeto-04-02     | Projeto: Componentizando Elementos para Reutilização |
[Download](https://github.com/treinaweb/treinaweb-introducao-geradores-sites-estaticos/archive/projeto-04-03.zip)    |  projeto-04-03     | Projeto: Páginas de Receitas |
